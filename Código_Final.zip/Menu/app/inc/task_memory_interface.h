/*
 * Copyright (c) 2025 Nicolás Alejandro Potenza <npotenza@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_memory_interface.h
 * @date   : Dec 07, 2025
 * @author : Nicolás Alejandro Potenza <npotenza@fi.uba.ar>
 * @version	v1.0.0
 */

#ifndef TASK_INC_TASK_MEMORY_INTERFACE_H_
#define TASK_INC_TASK_MEMORY_INTERFACE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include "task_memory_attribute.h"
/********************** macros ***********************************************/

/********************** typedef **********************************************/

/********************** external data declaration ****************************/
extern uint8_t memory_ram[MAX_MEMORY];
extern I2C_HandleTypeDef *eeprom_i2c;

/********************** external functions declaration ***********************/
extern void init_queue_event_task_memory(void);
extern void config_i2c_task_memory(I2C_HandleTypeDef *hi2c);
extern void put_string_task_memory(uint16_t address, uint8_t *string, uint16_t length);
extern void get_string_task_memory(uint16_t address, uint16_t length);
extern uint32_t get_tail_task_memory(void);
extern task_memory_req_t get_event_task_memory(void);
extern bool any_event_task_memory(void);
extern bool task_memory_is_idle(void);

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_INC_TASK_MEMORY_INTERFACE_H_ */

/********************** end of file ******************************************/

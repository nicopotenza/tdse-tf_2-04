/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_txpresion_attribute.h
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

#ifndef TASK_INC_TASK_TXPRESION_ATTRIBUTE_H_
#define TASK_INC_TASK_TXPRESION_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/

/********************** macros ***********************************************/
#define TXPRESION_OUT_MIN   (-125)
#define TXPRESION_OUT_MED      (0)
#define TXPRESION_OUT_MAX   ( 125)
#define TXPRESION_RAW_MIN      (0)
#define TXPRESION_RAW_MAX   (4095)

/********************** typedef **********************************************/

/* Events to excite Task txPresion */
typedef enum task_txpresion_ev {
	EV_TXPRESION_IDLE, EV_TXPRESION_OK, EV_TXPRESION_ERROR
} task_txpresion_ev_t;

/* States of Task txPresion */
typedef enum task_txpresion_st {
	ST_TXPRESION_IDLE, ST_TXPRESION_WAIT
} task_txpresion_st_t;

/* Identifier of Task txPresion */
typedef enum task_txpresion_id {
	ID_TXPRESION_0, ID_TXPRESION_1
} task_txpresion_id_t;

typedef struct {
	task_txpresion_id_t identifier;
	ADC_ChannelConfTypeDef sConfig;

	int32_t raw_min;
	int32_t raw_max;

	int16_t offset;
	int16_t out_min;
	int16_t out_max;
} task_txpresion_cfg_t;

typedef struct {
	uint32_t tick;
	task_txpresion_st_t state;
	task_txpresion_ev_t event;

	volatile bool req;
	volatile bool done;

	volatile uint16_t latest_raw;
	volatile bool latest_valid;
	volatile int16_t latest_scaled;
	volatile int16_t latest_scaled_without_offset;
} task_txpresion_dta_t;

/********************** external data declaration ****************************/
extern task_txpresion_dta_t task_txpresion_dta_list[];

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_INC_TASK_TXPRESION_ATTRIBUTE_H_ */

/********************** end of file ******************************************/

/*
 * Copyright (c) 2025 Nicolás Alejandro Potenza <npotenza@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_memory_attribute.h
 * @date   : Dec 07, 2025
 * @author : Nicolás Alejandro Potenza <npotenza@fi.uba.ar>
 * @version	v1.0.0
 */

#ifndef TASK_INC_TASK_MEMORY_ATTRIBUTE_H_
#define TASK_INC_TASK_MEMORY_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/

/********************** macros ***********************************************/
#define MAX_MEMORY			(0x0400)

#define EEPROM_I2C_ADDR    	(0x50 << 1)
#define EEPROM_PAGE_SIZE	(16u)	/* 16 bytes por página */

/********************** typedef **********************************************/

/* Events to excite Task Memory */
typedef enum task_memory_ev {
	EV_MEM_IDLE, EV_MEM_READ, EV_MEM_WRITE
} task_memory_ev_t;

typedef struct {
    task_memory_ev_t event;
    uint16_t address;
    uint16_t length;
} task_memory_req_t;

/* State of Task Memory */
typedef enum task_memory_st {
	ST_MEM_IDLE,
	ST_MEM_WRITE,
	ST_MEM_WRITING,
    ST_MEM_WRITE_POLL,
    ST_MEM_SET_ADDRESS,
	ST_MEM_READ,
	ST_MEM_READING
} task_memory_st_t;

typedef struct {
	uint32_t tick;
	task_memory_st_t state;
	task_memory_ev_t event;
	bool flag;
} task_memory_dta_t;

/********************** external data declaration ****************************/
extern task_memory_dta_t task_memory_dta_list[];

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_INC_TASK_MEMORY_ATTRIBUTE_H_ */

/********************** end of file ******************************************/

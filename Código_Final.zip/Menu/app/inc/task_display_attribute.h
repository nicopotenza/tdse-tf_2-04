/*
 * Copyright (c) 2025 Nicolás Alejandro Potenza <npotenza@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_display_attribute.h
 * @date   : Nov 25, 2025
 * @author : Nicolás Alejandro Potenza <npotenza@fi.uba.ar>
 * @version	v1.0.0
 */

#ifndef TASK_INC_TASK_DISPLAY_ATTRIBUTE_H_
#define TASK_INC_TASK_DISPLAY_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/

/********************** macros ***********************************************/
#define MAX_ROWS			(4)
#define MAX_COLUMNS			(20)

#define LCD_I2C_ADDR    	(0x27 << 1)
#define LCD_BACKLIGHT_ON	(0x08)
#define LCD_BACKLIGHT_OFF	(0x00)
#define LCD_EN				(0x04)
#define LCD_RW				(0x02)
#define LCD_RS				(0x01)

/********************** typedef **********************************************/

/* Events to excite Task Display */
typedef enum task_display_ev {
	EV_DIS_IDLE, EV_DIS_WRITE, EV_DIS_BACKLIGHT
} task_display_ev_t;

/* State of Task Display */
typedef enum task_display_st {
	ST_DIS_IDLE, ST_DIS_ACTIVE_01, ST_DIS_ACTIVE_02, ST_DIS_BACKLIGHT
} task_display_st_t;

typedef struct {
	uint32_t tick;
	task_display_st_t state;
	task_display_ev_t event;
	bool flag;
} task_display_dta_t;

/********************** external data declaration ****************************/
extern task_display_dta_t task_display_dta_list[];

extern uint8_t lcd_backlight;

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_INC_TASK_DISPLAY_ATTRIBUTE_H_ */

/********************** end of file ******************************************/

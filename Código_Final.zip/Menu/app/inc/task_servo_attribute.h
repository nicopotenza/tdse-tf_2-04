/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_servo_attribute.h
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

#ifndef TASK_INC_TASK_SERVO_ATTRIBUTE_H_
#define TASK_INC_TASK_SERVO_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/

/********************** macros ***********************************************/

/********************** typedef **********************************************/

/* Events to excite Task Servo */
typedef enum task_servo_ev {
	EV_SERVO_DISABLE, EV_SERVO_ENABLE, EV_SERVO_SET_ANGLE
} task_servo_ev_t;

/* States of Task Servo */
typedef enum task_servo_st {
	ST_SERVO_DISABLED, ST_SERVO_IDLE, ST_SERVO_MOVING
} task_servo_st_t;

/* Identifier of Task Servo */
typedef enum task_servo_id {
	ID_SERVO_1
} task_servo_id_t;

typedef struct {
	task_servo_id_t      identifier;
	TIM_HandleTypeDef   *htim;
	uint32_t             channel;

	uint16_t             pulse_min_us;
	uint16_t             pulse_max_us;

	int16_t              angle_min_deg;
	int16_t              angle_max_deg;

	uint16_t             period_us;

	uint16_t             step_delay_ms;
} task_servo_cfg_t;

typedef struct {
	uint32_t         tick;

	task_servo_st_t  state;
	task_servo_ev_t  event;
	bool             flag;

	int16_t          angle_current_deg;
	int16_t          angle_target_deg;
} task_servo_dta_t;

/********************** external data declaration ****************************/
extern task_servo_dta_t task_servo_dta_list[];

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_INC_TASK_SERVO_ATTRIBUTE_H_ */

/********************** end of file ******************************************/

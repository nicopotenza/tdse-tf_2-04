/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_txpresion.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_txpresion_attribute.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"

/********************** macros and definitions *******************************/
#define G_TASK_TXPRESION_CNT_INIT		0ul
#define G_TASK_TXPRESION_TICK_CNT_INI	0ul

#define DEL_TXPRESION_MIN				0ul
#define DEL_TXPRESION_MED				100ul
#define DEL_TXPRESION_MAX				500ul

#define TXPRESION_ADC_INSTANCE			(ADC1)
#define TXPRESION_OSR_SAMPLES            4u      // 1,2,4,8,16...

/********************** internal data declaration ****************************/
ADC_HandleTypeDef *hadc;

task_txpresion_cfg_t task_txpresion_cfg_list[] = { { ID_TXPRESION_0, {
ADC_CHANNEL_0, ADC_REGULAR_RANK_1, ADC_SAMPLETIME_55CYCLES_5 },
TXPRESION_RAW_MIN, TXPRESION_RAW_MAX, 0, TXPRESION_OUT_MIN,
TXPRESION_OUT_MAX }, { ID_TXPRESION_1, { ADC_CHANNEL_1,
ADC_REGULAR_RANK_1, ADC_SAMPLETIME_55CYCLES_5 }, TXPRESION_RAW_MIN,
TXPRESION_RAW_MAX, 0, TXPRESION_OUT_MIN, TXPRESION_OUT_MAX } };

#define TXPRESION_CFG_QTY	(sizeof(task_txpresion_cfg_list)/sizeof(task_txpresion_cfg_t))

task_txpresion_dta_t task_txpresion_dta_list[] = { { DEL_TXPRESION_MIN,
		ST_TXPRESION_IDLE, EV_TXPRESION_IDLE, false, false, 0, false, 0, 0 }, {
DEL_TXPRESION_MIN, ST_TXPRESION_IDLE, EV_TXPRESION_IDLE, false, false, 0, false,
		0, 0 } };

#define TXPRESION_DTA_QTY	(sizeof(task_txpresion_dta_list)/sizeof(task_txpresion_dta_t))

/* “Arbitraje” del ADC compartido */
static volatile bool g_adc_busy;
static volatile uint8_t g_adc_owner;

/* Oversampling accumulator */
static volatile uint32_t g_adc_accum;
static volatile uint8_t g_adc_count;
static volatile uint16_t g_adc_last_raw_avg;

/********************** internal functions declaration ***********************/
static void task_txpresion_statechart(void);
static void txpresion_adc_dispatcher(void);

static int16_t txpresion_scale_raw(const task_txpresion_cfg_t *cfg,
		uint16_t raw, int16_t *scaled_without_offset);

/********************** internal data definition *****************************/
const char *p_task_txpresion = "Task txPresion (txPresion Statechart)";
const char *p_task_txpresion_ = "Non-Blocking & Update By Time Code";

/********************** external data declaration ****************************/
uint32_t g_task_txpresion_cnt;
volatile uint32_t g_task_txpresion_tick_cnt;

/********************** external functions definition ************************/
void config_adc_task_txpresion(ADC_HandleTypeDef *adc) {
	hadc = adc;
}

void task_txpresion_init(void *parameters) {
	uint32_t index;
	task_txpresion_dta_t *p_task_txpresion_dta;
	task_txpresion_st_t state;
	task_txpresion_ev_t event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - %s", GET_NAME(task_txpresion_init),
			p_task_txpresion);
	LOGGER_INFO("  %s is a %s", GET_NAME(task_txpresion), p_task_txpresion_);

	/* Init & Print out: Task execution counter */
	g_task_txpresion_cnt = G_TASK_TXPRESION_CNT_INIT;
	LOGGER_INFO("   %s = %lu", GET_NAME(g_task_txpresion_cnt),
			g_task_txpresion_cnt);

	g_adc_busy = false;
	g_adc_owner = 0xFF;
	g_adc_accum = 0;
	g_adc_count = 0;
	g_adc_last_raw_avg = 0;

	if (hadc != NULL) {
		HAL_ADCEx_Calibration_Start(hadc);
	}

	for (index = 0; TXPRESION_DTA_QTY > index; index++) {
		/* Update Task txPresion Data Pointer */
		p_task_txpresion_dta = &task_txpresion_dta_list[index];

		/* Init & Print out: Index & Task execution FSM */
		state = ST_TXPRESION_IDLE;
		p_task_txpresion_dta->state = state;

		event = EV_TXPRESION_IDLE;
		p_task_txpresion_dta->event = event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu", GET_NAME(index), index,
				GET_NAME(state), (uint32_t )state, GET_NAME(event),
				(uint32_t )event);
	}
}

void task_txpresion_update(void *parameters) {
	bool b_time_update_required = false;

	/* Protect shared resource */
	__asm("CPSID i");
	/* disable interrupts */
	if (G_TASK_TXPRESION_TICK_CNT_INI < g_task_txpresion_tick_cnt) {
		/* Update Tick Counter */
		g_task_txpresion_tick_cnt--;
		b_time_update_required = true;
	}
	__asm("CPSIE i");
	/* enable interrupts */

	while (b_time_update_required) {
		/* Update Task Counter */
		g_task_txpresion_cnt++;

		/* Run Task Statechart */
		task_txpresion_statechart();

		/* Protect shared resource */
		__asm("CPSID i");
		/* disable interrupts */
		if (G_TASK_TXPRESION_TICK_CNT_INI < g_task_txpresion_tick_cnt) {
			/* Update Tick Counter */
			g_task_txpresion_tick_cnt--;
			b_time_update_required = true;
		} else {
			b_time_update_required = false;
		}
		__asm("CPSIE i");
		/* enable interrupts */
	}
}

void task_txpresion_statechart(void) {
	uint32_t index;
	task_txpresion_dta_t *p_task_txpresion_dta;
	task_txpresion_cfg_t *p_task_txpresion_cfg;

	for (index = 0; TXPRESION_DTA_QTY > index; index++) {
		/* Update Task txPresion Configuration & Data Pointer */
		p_task_txpresion_dta = &task_txpresion_dta_list[index];
		p_task_txpresion_cfg = &task_txpresion_cfg_list[index];

		switch (p_task_txpresion_dta->state) {
		case ST_TXPRESION_IDLE:
			if (p_task_txpresion_dta->tick > DEL_TXPRESION_MIN) {
				p_task_txpresion_dta->tick--;
			} else {
				p_task_txpresion_dta->req = true;
				p_task_txpresion_dta->state = ST_TXPRESION_WAIT;
				p_task_txpresion_dta->event = EV_TXPRESION_IDLE;
			}
			break;

		case ST_TXPRESION_WAIT:
			if (p_task_txpresion_dta->done) {
				p_task_txpresion_dta->done = false;

				p_task_txpresion_dta->latest_raw = g_adc_last_raw_avg;
				p_task_txpresion_dta->latest_scaled = txpresion_scale_raw(
						p_task_txpresion_cfg, p_task_txpresion_dta->latest_raw, &p_task_txpresion_dta->latest_scaled_without_offset);
				p_task_txpresion_dta->latest_valid = true;

				p_task_txpresion_dta->tick = DEL_TXPRESION_MAX;

				p_task_txpresion_dta->state = ST_TXPRESION_IDLE;
				p_task_txpresion_dta->event = EV_TXPRESION_OK;
			}
			break;
		default:
			p_task_txpresion_dta->state = ST_TXPRESION_IDLE;
			p_task_txpresion_dta->event = EV_TXPRESION_IDLE;
		}
	}

	txpresion_adc_dispatcher();
}

static void txpresion_adc_dispatcher(void) {
	static uint32_t rr_next = 0;

	if (hadc == NULL)
		return;
	if (g_adc_busy)
		return;

	/* Si algún canal pidió ser leído, arrancando desde rr_next */
	for (uint32_t k = 0; k < TXPRESION_DTA_QTY; k++) {
		uint32_t idx = (rr_next + k) % TXPRESION_DTA_QTY;

		task_txpresion_dta_t *p_task_txpresion_dta =
				&task_txpresion_dta_list[idx];
		task_txpresion_cfg_t *p_task_txpresion_cfg =
				&task_txpresion_cfg_list[idx];

		if (!p_task_txpresion_dta->req)
			continue;

		/* Tomo ownership */
		p_task_txpresion_dta->req = false;
		g_adc_owner = (uint8_t) idx;
		g_adc_busy = true;

		/* Reset oversampling */
		g_adc_accum = 0;
		g_adc_count = 0;

		/* Configurar canal y arrancar 1ra conversión */
		if (HAL_ADC_ConfigChannel(hadc, &p_task_txpresion_cfg->sConfig)
				!= HAL_OK) {
			g_adc_busy = false;
			p_task_txpresion_dta->req = true;
			p_task_txpresion_dta->event = EV_TXPRESION_ERROR;
			return;
		}

		if (HAL_ADC_Start_IT(hadc) != HAL_OK) {
			g_adc_busy = false;
			p_task_txpresion_dta->req = true;
			p_task_txpresion_dta->event = EV_TXPRESION_ERROR;
			return;
		}

		rr_next = (idx + 1u) % TXPRESION_DTA_QTY;
		return;
	}
}

static int16_t txpresion_scale_raw(const task_txpresion_cfg_t *cfg,
		uint16_t raw_u16, int16_t *scaled_without_offset) {
	int32_t raw = (int32_t) raw_u16;

	int32_t raw_min = cfg->raw_min;
	int32_t raw_max = cfg->raw_max;

	if (raw_max <= raw_min) {
		int32_t y = (int32_t) cfg->offset;
		if (y < cfg->out_min)
			y = cfg->out_min;
		if (y > cfg->out_max)
			y = cfg->out_max;
		return (int16_t) y;
	}

	if (raw < raw_min)
		raw = raw_min;
	if (raw > raw_max)
		raw = raw_max;

	/* y = out_min + (raw-raw_min)*(out_max-out_min)/(raw_max-raw_min) */
	int32_t out_min = (int32_t) cfg->out_min;
	int32_t out_max = (int32_t) cfg->out_max;

	int32_t num = (raw - raw_min) * (out_max - out_min);
	int32_t den = (raw_max - raw_min);

	int32_t y = out_min + (num / den);

	*scaled_without_offset = y;

	/* offset */
	y += (int32_t) cfg->offset;

	/* clamp final */
	if (y < out_min)
		y = out_min;
	if (y > out_max)
		y = out_max;

	return (int16_t) y;
}

uint16_t task_txpresion_get_latest_raw(task_txpresion_id_t id, uint8_t *p_valid) {
	uint32_t idx = (uint32_t) id;
	if (idx >= TXPRESION_DTA_QTY) {
		if (p_valid)
			*p_valid = 0u;
		return 0u;
	}

	if (p_valid)
		*p_valid = (task_txpresion_dta_list[idx].latest_valid) ? 1u : 0u;

	return task_txpresion_dta_list[idx].latest_raw;
}

int16_t task_txpresion_get_latest_scaled(task_txpresion_id_t id,
bool *p_valid) {
	uint32_t idx = (uint32_t) id;
	if (idx >= TXPRESION_DTA_QTY) {
		if (p_valid)
			*p_valid = false;
		return 0;
	}

	if (p_valid)
		*p_valid = (task_txpresion_dta_list[idx].latest_valid) ? true : false;

	return task_txpresion_dta_list[idx].latest_scaled;
}

int16_t task_txpresion_get_latest_scaled_2(task_txpresion_id_t id,
bool *p_valid) {
	uint32_t idx = (uint32_t) id;
	if (idx >= TXPRESION_DTA_QTY) {
		if (p_valid)
			*p_valid = false;
		return 0;
	}

	if (p_valid)
		*p_valid = (task_txpresion_dta_list[idx].latest_valid) ? true : false;

	return task_txpresion_dta_list[idx].latest_scaled_without_offset;
}

void task_txpresion_set_offset(task_txpresion_id_t id, int16_t offset) {
	if (id >= TXPRESION_DTA_QTY)
		return;

	task_txpresion_cfg_list[id].offset = offset;
}

int16_t task_txpresion_get_offset(task_txpresion_id_t id) {
	if (id >= TXPRESION_DTA_QTY)
		return 0;

	return task_txpresion_cfg_list[id].offset;
}

/* ===================== HAL callbacks ===================== */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
	if (hadc->Instance != TXPRESION_ADC_INSTANCE)
		return;
	if (!g_adc_busy)
		return;
	if (g_adc_owner >= TXPRESION_DTA_QTY) {
		g_adc_busy = false;
		return;
	}

	uint16_t sample = (uint16_t) HAL_ADC_GetValue(hadc);

	g_adc_accum += (uint32_t) sample;
	g_adc_count++;

	if (g_adc_count < TXPRESION_OSR_SAMPLES) {
		/* Disparar otra conversión del MISMO canal (oversampling) */
		(void) HAL_ADC_Start_IT(hadc);
		return;
	}

	/* Medición completa: promedio */
	g_adc_last_raw_avg = (uint16_t) (g_adc_accum
			/ (uint32_t) TXPRESION_OSR_SAMPLES);

	g_adc_busy = false;
	task_txpresion_dta_list[g_adc_owner].done = true;
}
/********************** end of file ******************************************/

/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_system.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"
#include "task_txpresion.h"
#include "task_txpresion_attribute.h"
#include "task_servo_attribute.h"
#include "task_servo_interface.h"
#include "task_led_attribute.h"
#include "task_led_interface.h"
#include "task_buzzer_attribute.h"
#include "task_buzzer_interface.h"
#include "task_display_attribute.h"
#include "task_display_interface.h"
#include "task_memory_attribute.h"
#include "task_memory_interface.h"


/********************** macros and definitions *******************************/
#define G_TASK_SYS_CNT_INI			    0ul
#define G_TASK_SYS_TICK_CNT_INI		    0ul

#define DEL_SYS_MIN					    0ul
#define DEL_SYS_MED					   50ul
#define DEL_SYS_MAX					  500ul
#define DEL_SYS_EEPROM			   	 2000ul
#define DEL_SYS_ALERT			   	 3000ul
#define DEL_SYS_STABILIZING		   	 5000ul

#define MIN_SALA_PASILLO		     TXPRESION_OUT_MED
#define MAX_SALA_PASILLO			 TXPRESION_OUT_MAX
#define MIN_SALA_HABITACION_INMUNO	 TXPRESION_OUT_MIN
#define MAX_SALA_HABITACION_INMUNO	 TXPRESION_OUT_MED
#define MIN_SALA_HABITACION_INFECTO  TXPRESION_OUT_MED
#define MAX_SALA_HABITACION_INFECTO	 TXPRESION_OUT_MAX

#define MIN_SALA_PASILLO_SENSOR		 TXPRESION_OUT_MIN
#define MAX_SALA_PASILLO_SENSOR		 TXPRESION_OUT_MAX
#define MIN_SALA_HABITACION_SENSOR	 TXPRESION_OUT_MIN
#define MAX_SALA_HABITACION_SENSOR	 TXPRESION_OUT_MAX

#define MIN_DESVIO_SP					  0
#define MAX_DESVIO_SP				     20

#define MIN_PORCENTAJE					  0
#define MAX_PORCENTAJE				    100

typedef enum memory_data {
	MEMORY_MODE = 0,
	MEMORY_SALA_PASILLO_SP_H,
	MEMORY_SALA_PASILLO_SP_L,
	MEMORY_SALA_PASILLO_OFFSET_H,
	MEMORY_SALA_PASILLO_OFFSET_L,
	MEMORY_SALA_PASILLO_DESVIO_H,
	MEMORY_SALA_PASILLO_DESVIO_L,
	MEMORY_SALA_HABITACION_SP_H,
	MEMORY_SALA_HABITACION_SP_L,
	MEMORY_SALA_HABITACION_OFFSET_H,
	MEMORY_SALA_HABITACION_OFFSET_L,
	MEMORY_SALA_HABITACION_DESVIO_H,
	MEMORY_SALA_HABITACION_DESVIO_L,
	MEMORY_LENGTH
} memory_data_t;

typedef enum task_system_md {
	SET_UP = 0, INMUNO, INFECTO
} task_system_md_t;
#define INDEFINED_TASK_SYSTEM 		  255
/********************** internal data declaration ****************************/
task_system_dta_t task_system_dta_list[] = { { DEL_SYS_MIN, ST_SYS_READ_EEPROM,
		EV_SYS_IDLE, false }, {
DEL_SYS_STABILIZING, ST_SYS_STABILIZING, EV_SYS_IDLE,
false }, { DEL_SYS_STABILIZING, ST_SYS_STABILIZING, EV_SYS_IDLE,
false } };

#define SYSTEM_DTA_QTY	(sizeof(task_system_dta_list)/sizeof(task_system_dta_t))

task_system_md_t task_system_mode;

/********************** internal functions declaration ***********************/
void task_system_statechart_SET_UP(void);
void task_system_statechart_INMUNO(void);
void task_system_statechart_INFECTO(void);

/********************** internal data definition *****************************/
const char *p_task_system = "Task System (System Statechart)";
const char *p_task_system_ = "Non-Blocking & Update By Time Code";

static uint8_t linea1[MAX_COLUMNS + 1];
static uint8_t linea2[MAX_COLUMNS + 1];
static uint8_t linea3[MAX_COLUMNS + 1];
static uint8_t linea4[MAX_COLUMNS + 1];
static bool change = true;
static bool print = true;

int16_t sala_pasillo_SP;
int16_t sala_habitacion_SP;

int16_t sala_pasillo_PV;
int16_t sala_habitacion_PV;

int16_t sala_pasillo_desvio;
int16_t sala_habitacion_desvio;

int16_t sala_pasillo_offset;
int16_t sala_habitacion_offset;

int16_t actuador_angulo;
int16_t actuador_porcentaje;

bool backlight = true;

int16_t modulacion(int16_t medido, int16_t seteo, int16_t desvio);
bool estable(int16_t medido, int16_t seteo, int16_t desvio);
void estadoLeds(task_led_ev_t l1, task_led_ev_t l2, task_led_ev_t l3,
		task_led_ev_t l4);
/********************** external data declaration ****************************/
uint32_t g_task_system_cnt;
volatile uint32_t g_task_system_tick_cnt;

/********************** external functions definition ************************/
void task_system_init(void *parameters) {
	uint16_t index;
	task_system_dta_t *p_task_system_dta;
	task_system_st_t state;
	task_system_ev_t event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - %s", GET_NAME(task_system_init),
			p_task_system);
	LOGGER_INFO("  %s is a %s", GET_NAME(task_system), p_task_system_);

	/* Init & Print out: Task execution counter */
	g_task_system_cnt = G_TASK_SYS_CNT_INI;
	LOGGER_INFO("   %s = %lu", GET_NAME(g_task_system_cnt), g_task_system_cnt);

	for (index = 0; SYSTEM_DTA_QTY > index; index++) {
		/* Update Task system Configuration & Data Pointer */
		p_task_system_dta = &task_system_dta_list[index];

		/* Init & Print out: Task execution FSM */
		state = ST_SYS_IDLE;
		p_task_system_dta->state = state;

		event = EV_SYS_IDLE;
		p_task_system_dta->event = event;

		b_event = false;
		p_task_system_dta->flag = b_event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu", GET_NAME(index), index,
				GET_NAME(state), (uint32_t )state, GET_NAME(event),
				(uint32_t )event);
	}

	init_queue_event_task_system();

	if (true == change) {
		snprintf(linea1, sizeof(linea1), "SET UP ~ MEM. EEPROM");
		snprintf(linea2, sizeof(linea2), "                    ");
		snprintf(linea3, sizeof(linea3), "LEYENDO ............");
		snprintf(linea4, sizeof(linea4), "                    ");
		put_string_task_display(0, 0, linea1, MAX_COLUMNS);
		put_string_task_display(1, 0, linea2, MAX_COLUMNS);
		put_string_task_display(2, 0, linea3, MAX_COLUMNS);
		put_string_task_display(3, 0, linea4, MAX_COLUMNS);

		put_event_task_display(EV_DIS_WRITE);

		p_task_system_dta->tick = DEL_SYS_EEPROM;
		change = false;
	}

	task_system_mode = INDEFINED_TASK_SYSTEM;
}

void task_system_update(void *parameters) {
	bool b_time_update_required = false;
	static bool consultado = false;

	/* Protect shared resource */
	__asm("CPSID i");
	/* disable interrupts */
	if (G_TASK_SYS_TICK_CNT_INI < g_task_system_tick_cnt) {
		/* Update Tick Counter */
		g_task_system_tick_cnt--;
		b_time_update_required = true;
	}
	__asm("CPSIE i");
	/* enable interrupts */

	while (b_time_update_required) {
		/* Update Task Counter */
		g_task_system_cnt++;

		/* Run Task Statechart */
		switch (task_system_mode) {
		case SET_UP:
			task_system_statechart_SET_UP();
			if (task_system_mode == INMUNO) {
				task_system_dta_list[INMUNO].state = ST_SYS_IDLE;
			}
			if (task_system_mode == INFECTO) {
				task_system_dta_list[INFECTO].state = ST_SYS_IDLE;
			}
			break;
		case INMUNO:
			task_system_statechart_INMUNO();
			if (task_system_mode == SET_UP) {
				task_system_dta_list[SET_UP].state = ST_SYS_IDLE;
			}
			break;
		case INFECTO:
			task_system_statechart_INFECTO();
			if (task_system_mode == SET_UP) {
				task_system_dta_list[SET_UP].state = ST_SYS_IDLE;
			}
			break;
		default:
			if (false == consultado) {
				get_string_task_memory(MEMORY_MODE, MEMORY_LENGTH);
				consultado = true;
			} else {
				if (true == any_event_task_system()
						&& EV_SYS_MEM_READ_DONE == get_event_task_system()) {
					sala_pasillo_SP =
							(int16_t) ((memory_ram[MEMORY_SALA_PASILLO_SP_H]
									<< 8) | memory_ram[MEMORY_SALA_PASILLO_SP_L]);

					sala_pasillo_offset =
							(int16_t) ((memory_ram[MEMORY_SALA_PASILLO_OFFSET_H]
									<< 8)
									| memory_ram[MEMORY_SALA_PASILLO_OFFSET_L]);
					task_txpresion_set_offset(ID_TXPRESION_0,
							sala_pasillo_offset);

					sala_pasillo_desvio =
							(int16_t) ((memory_ram[MEMORY_SALA_PASILLO_DESVIO_H]
									<< 8)
									| memory_ram[MEMORY_SALA_PASILLO_DESVIO_L]);

					sala_habitacion_SP =
							(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_SP_H]
									<< 8)
									| memory_ram[MEMORY_SALA_HABITACION_SP_L]);

					sala_habitacion_offset =
							(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_OFFSET_H]
									<< 8)
									| memory_ram[MEMORY_SALA_HABITACION_OFFSET_L]);
					task_txpresion_set_offset(ID_TXPRESION_1,
							sala_habitacion_offset);

					sala_habitacion_desvio =
							(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_DESVIO_H]
									<< 8)
									| memory_ram[MEMORY_SALA_HABITACION_DESVIO_L]);

					task_system_mode = (
							!memory_ram[MEMORY_MODE] ? INMUNO : INFECTO);
					put_event_task_servo(EV_SERVO_ENABLE, ID_SERVO_1);
				}
			}
		}

		/* Protect shared resource */
		__asm("CPSID i");
		/* disable interrupts */
		if (G_TASK_SYS_TICK_CNT_INI < g_task_system_tick_cnt) {
			/* Update Tick Counter */
			g_task_system_tick_cnt--;
			b_time_update_required = true;
		} else {
			b_time_update_required = false;
		}
		__asm("CPSIE i");
		/* enable interrupts */
	}
}

void task_system_statechart_SET_UP(void) {
	static int16_t sala_pasillo;
	static int16_t sala_habitacion;
	static int16_t sala_pasillo_off;
	static int16_t sala_habitacion_off;
	static int16_t sala_pasillo_des;
	static int16_t sala_habitacion_des;

	static int16_t medicion;
	static int16_t temp_med;
	static bool med_ok = false;

	static bool inmuno_infecto = false;
	static uint8_t data[MEMORY_LENGTH];

	task_system_dta_t *p_task_system_dta;

	/* Update Task System Data Pointer */
	p_task_system_dta = &task_system_dta_list[SET_UP];

	if (true == any_event_task_system()) {
		p_task_system_dta->flag = true;
		p_task_system_dta->event = get_event_task_system();
	}
	estadoLeds(EV_LED_OFF, EV_LED_OFF, EV_LED_OFF, EV_LED_OFF);
	put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);

	switch (p_task_system_dta->state) {
	// Tomo info de la memoria
	case ST_SYS_READ_EEPROM:
		static bool consultado = false;
		static bool leido = false;

		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ MEM. EEPROM");
			snprintf(linea2, sizeof(linea2), "                    ");
			snprintf(linea3, sizeof(linea3), "LEYENDO ............");
			snprintf(linea4, sizeof(linea4), "                    ");
			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			p_task_system_dta->tick = DEL_SYS_EEPROM;
			change = false;
		}

		if (false == consultado) {
			get_string_task_memory(MEMORY_MODE, MEMORY_LENGTH);
			consultado = true;
		} else {
			if ((true == p_task_system_dta->flag)
					&& (EV_SYS_MEM_READ_DONE == p_task_system_dta->event)) {

				sala_pasillo = (int16_t) ((memory_ram[MEMORY_SALA_PASILLO_SP_H]
						<< 8) | memory_ram[MEMORY_SALA_PASILLO_SP_L]);
				sala_pasillo_off =
						(int16_t) ((memory_ram[MEMORY_SALA_PASILLO_OFFSET_H]
								<< 8) | memory_ram[MEMORY_SALA_PASILLO_OFFSET_L]);
				sala_pasillo_des =
						(int16_t) ((memory_ram[MEMORY_SALA_PASILLO_DESVIO_H]
								<< 8) | memory_ram[MEMORY_SALA_PASILLO_DESVIO_L]);

				sala_habitacion =
						(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_SP_H] << 8)
								| memory_ram[MEMORY_SALA_HABITACION_SP_L]);
				sala_habitacion_off =
						(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_OFFSET_H]
								<< 8)
								| memory_ram[MEMORY_SALA_HABITACION_OFFSET_L]);
				sala_habitacion_des =
						(int16_t) ((memory_ram[MEMORY_SALA_HABITACION_DESVIO_H]
								<< 8)
								| memory_ram[MEMORY_SALA_HABITACION_DESVIO_L]);

				inmuno_infecto = (bool) memory_ram[MEMORY_MODE];

				p_task_system_dta->flag = false;
				leido = true;
			}
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (true == leido) {
			p_task_system_dta->state = ST_SYS_SELECT_MODE;
			change = true;
		}

		break;

	case ST_SYS_SELECT_MODE:
		// Seleccionar Modo
		if (true == change) {

			snprintf(linea1, sizeof(linea1), "SET UP ~ MODO       ");
			snprintf(linea2, sizeof(linea2), "                    ");
			if (false == inmuno_infecto) {
				snprintf(linea3, sizeof(linea3), "~ INMUNOSUPRIMIDO   ");
				snprintf(linea4, sizeof(linea4), "  INFECTOCONTAGIOSO ");
			} else {
				snprintf(linea3, sizeof(linea3), "  INMUNOSUPRIMIDO   ");
				snprintf(linea4, sizeof(linea4), "~ INFECTOCONTAGIOSO ");
			}
			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			p_task_system_dta->tick = DEL_SYS_MED;
			change = false;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				if (false == inmuno_infecto) {
					task_system_mode = INMUNO;
				} else {
					task_system_mode = INFECTO;
				}
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_AP;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				inmuno_infecto = false;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				inmuno_infecto = true;
				break;
			default:
				break;
			}
		}

		break;

	case ST_SYS_MODIFY_AP:
		// Seleccionar diferencia antesala/pasillo
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 1 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-PASILLO    ");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_pasillo);
			snprintf(linea4, sizeof(linea4), "Rango [%4da%4d] Pa",
			MIN_SALA_PASILLO,
			MAX_SALA_PASILLO);

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_SELECT_MODE;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_OFFSET_AP;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo < MAX_SALA_PASILLO)
					sala_pasillo++;
				else
					sala_pasillo = MAX_SALA_PASILLO;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo > MIN_SALA_PASILLO)
					sala_pasillo--;
				else
					sala_pasillo = MIN_SALA_PASILLO;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_MODIFY_OFFSET_AP:
		temp_med = task_txpresion_get_latest_scaled_2(ID_TXPRESION_0, &med_ok);
		if (med_ok)
			medicion = temp_med;
		// Seleccionar diferencia de sensor antesala/pasillo
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 1 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-PAS. OFFSET");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_pasillo_off);
			snprintf(linea4, sizeof(linea4), "PV+offset = %4d Pa ",
					(medicion + sala_pasillo_off));

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_AP;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_DESVIO_AP;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo_off < TXPRESION_OUT_MAX)
					sala_pasillo_off++;
				else
					sala_pasillo_off = TXPRESION_OUT_MAX;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo_off > TXPRESION_OUT_MIN)
					sala_pasillo_off--;
				else
					sala_pasillo_off = TXPRESION_OUT_MIN;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_MODIFY_DESVIO_AP:
		// Seleccionar diferencia PV vs SP antesala/pasillo
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 1 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-PAS. DESVIO");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_pasillo_des);
			snprintf(linea4, sizeof(linea4), "Rango [%2d a %2d] Pa  ",
			MIN_DESVIO_SP, MAX_DESVIO_SP);

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_OFFSET_AP;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_AH;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo_des < MAX_DESVIO_SP)
					sala_pasillo_des++;
				else
					sala_pasillo_des = MAX_DESVIO_SP;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_pasillo_des > MIN_DESVIO_SP)
					sala_pasillo_des--;
				else
					sala_pasillo_des = MIN_DESVIO_SP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_MODIFY_AH:
		// Seleccionar diferencia antesala/habitacion
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 2 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-HABITACION ");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_habitacion);
			if (false == inmuno_infecto)
				snprintf(linea4, sizeof(linea4), "Rango [%4da%4d] Pa",
				MIN_SALA_HABITACION_INMUNO, MAX_SALA_HABITACION_INMUNO);
			else
				snprintf(linea4, sizeof(linea4), "Rango [%4da%4d] Pa",
				MIN_SALA_HABITACION_INFECTO, MAX_SALA_HABITACION_INFECTO);

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			p_task_system_dta->tick = DEL_SYS_MED;
			change = false;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_DESVIO_AP;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_OFFSET_AH;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (false == inmuno_infecto) {
					if (sala_habitacion < MAX_SALA_HABITACION_INMUNO)
						sala_habitacion++;
					else
						sala_habitacion = MAX_SALA_HABITACION_INMUNO;
				} else {
					if (sala_habitacion < MAX_SALA_HABITACION_INFECTO)
						sala_habitacion++;
					else
						sala_habitacion = MAX_SALA_HABITACION_INFECTO;
				}

				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (false == inmuno_infecto) {
					if (sala_habitacion > MIN_SALA_HABITACION_INMUNO)
						sala_habitacion--;
					else
						sala_habitacion = MIN_SALA_HABITACION_INMUNO;
				} else {
					if (sala_habitacion > MIN_SALA_HABITACION_INFECTO)
						sala_habitacion--;
					else
						sala_habitacion = MIN_SALA_HABITACION_INFECTO;
				}
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_MODIFY_OFFSET_AH:
		temp_med = task_txpresion_get_latest_scaled_2(ID_TXPRESION_1, &med_ok);
		if (med_ok)
			medicion = temp_med;

		// Seleccionar diferencia antesala/pasillo
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 2 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-HAB. OFFSET");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_habitacion_off);
			snprintf(linea4, sizeof(linea4), "PV+offset = %4d Pa ",
					(medicion + sala_habitacion_off));

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_AP;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_DESVIO_AH;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_habitacion_off < TXPRESION_OUT_MAX)
					sala_habitacion_off++;
				else
					sala_habitacion_off = TXPRESION_OUT_MAX;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_habitacion_off > TXPRESION_OUT_MIN)
					sala_habitacion_off--;
				else
					sala_habitacion_off = TXPRESION_OUT_MIN;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_MODIFY_DESVIO_AH:
		// Seleccionar diferencia PV vs SP antesala/habitacion
		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ DIF PRES 2 ");
			snprintf(linea2, sizeof(linea2), "ANTESALA-HAB. DESVIO");
			snprintf(linea3, sizeof(linea3), "Valor  =  %4d Pa   ",
					sala_habitacion_des);
			snprintf(linea4, sizeof(linea4), "Rango [%2d a %2d] Pa  ",
			MIN_DESVIO_SP, MAX_DESVIO_SP);

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_OFFSET_AH;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_PROBE_ACTUATOR;
				actuador_porcentaje = (MAX_PORCENTAJE - MIN_PORCENTAJE) / 2;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_habitacion_des < MAX_DESVIO_SP)
					sala_habitacion_des++;
				else
					sala_habitacion_des = MAX_DESVIO_SP;
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (sala_habitacion_des > MIN_DESVIO_SP)
					sala_habitacion_des--;
				else
					sala_habitacion_des = MIN_DESVIO_SP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_PROBE_ACTUATOR:
		// Forzar valor en actuador
		temp_med = task_txpresion_get_latest_scaled_2(ID_TXPRESION_0, &med_ok);
		if (med_ok)
			sala_pasillo_PV = temp_med + sala_pasillo_off;
		temp_med = task_txpresion_get_latest_scaled_2(ID_TXPRESION_1, &med_ok);
		if (med_ok)
			sala_habitacion_PV = temp_med + sala_habitacion_off;

		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ ACTUADOR   ");
			snprintf(linea2, sizeof(linea2), "APERTURA =  %3d %%   ",
					actuador_porcentaje);
			snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
			snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
					sala_pasillo_PV, sala_habitacion_PV);

			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);
			put_event_task_display(EV_DIS_WRITE);

			change = false;
			p_task_system_dta->tick = DEL_SYS_MED;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_BACK_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_MODIFY_DESVIO_AH;
				break;
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				p_task_system_dta->state = ST_SYS_WRITE_EEPROM;
				actuador_porcentaje = (MAX_PORCENTAJE - MIN_PORCENTAJE) / 2;
				break;
			case EV_SYS_BTN_UP_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (actuador_porcentaje < MAX_PORCENTAJE)
					actuador_porcentaje++;
				else
					actuador_porcentaje = MAX_PORCENTAJE;

				put_event_task_servo_set_angle(ID_SERVO_1,
						actuador_porcentaje * 1.8);
				put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);
				break;
			case EV_SYS_BTN_DOWN_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				if (actuador_porcentaje > MIN_PORCENTAJE)
					actuador_porcentaje--;
				else
					actuador_porcentaje = MIN_PORCENTAJE;

				put_event_task_servo_set_angle(ID_SERVO_1,
						actuador_porcentaje * 1.8);
				put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_WRITE_EEPROM:

		if (true == change) {
			snprintf(linea1, sizeof(linea1), "SET UP ~ MEM. EEPROM");
			snprintf(linea2, sizeof(linea2), "                    ");
			snprintf(linea3, sizeof(linea3), "ESCRIBIENDO ........");
			snprintf(linea4, sizeof(linea4), "                    ");
			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			p_task_system_dta->tick = DEL_SYS_EEPROM;
			change = false;
		}

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else {
			change = true;
			sala_pasillo_SP = sala_pasillo;
			sala_pasillo_offset = sala_pasillo_off;
			sala_pasillo_desvio = sala_pasillo_des;
			sala_habitacion_SP = sala_habitacion;
			sala_habitacion_offset = sala_habitacion_off;
			sala_habitacion_desvio = sala_habitacion_des;

			data[MEMORY_MODE] = (uint8_t) inmuno_infecto;

			data[MEMORY_SALA_PASILLO_SP_H] = (uint8_t) ((sala_pasillo >> 8)
					& 0xFF);
			data[MEMORY_SALA_PASILLO_SP_L] = (uint8_t) (sala_pasillo & 0xFF);

			data[MEMORY_SALA_PASILLO_OFFSET_H] = (uint8_t) ((sala_pasillo_off
					>> 8) & 0xFF);
			data[MEMORY_SALA_PASILLO_OFFSET_L] = (uint8_t) (sala_pasillo_off
					& 0xFF);

			data[MEMORY_SALA_PASILLO_DESVIO_H] = (uint8_t) ((sala_pasillo_des
					>> 8) & 0xFF);
			data[MEMORY_SALA_PASILLO_DESVIO_L] = (uint8_t) (sala_pasillo_des
					& 0xFF);

			data[MEMORY_SALA_HABITACION_SP_H] =
					(uint8_t) ((sala_habitacion >> 8) & 0xFF);
			data[MEMORY_SALA_HABITACION_SP_L] = (uint8_t) (sala_habitacion
					& 0xFF);

			data[MEMORY_SALA_HABITACION_OFFSET_H] =
					(uint8_t) ((sala_habitacion_off >> 8) & 0xFF);
			data[MEMORY_SALA_HABITACION_OFFSET_L] =
					(uint8_t) (sala_habitacion_off & 0xFF);

			data[MEMORY_SALA_HABITACION_DESVIO_H] =
					(uint8_t) ((sala_habitacion_des >> 8) & 0xFF);
			data[MEMORY_SALA_HABITACION_DESVIO_L] =
					(uint8_t) (sala_habitacion_des & 0xFF);

			put_string_task_memory(MEMORY_MODE, data, MEMORY_LENGTH);

			if ((true == p_task_system_dta->flag)
					&& (EV_SYS_MEM_WRITE_DONE == p_task_system_dta->event)) {
				p_task_system_dta->flag = false;

				task_txpresion_set_offset(ID_TXPRESION_0, sala_pasillo_offset);
				task_txpresion_set_offset(ID_TXPRESION_1,
						sala_habitacion_offset);

				if (false == inmuno_infecto) {
					task_system_mode = INMUNO;
				} else {
					task_system_mode = INFECTO;
				}
			}
		}
		break;

	default:

		p_task_system_dta->tick = DEL_SYS_MIN;
		p_task_system_dta->state = ST_SYS_READ_EEPROM;
		p_task_system_dta->event = EV_SYS_IDLE;
		p_task_system_dta->flag = false;
		leido = false;
		consultado = false;

		break;
	}
}

void task_system_statechart_INMUNO(void) {
	task_system_dta_t *p_task_system_dta;
	bool valido = false;
	int16_t temp;

	/* Update Task System Data Pointer */
	p_task_system_dta = &task_system_dta_list[INMUNO];

	if (true == any_event_task_system()) {
		p_task_system_dta->flag = true;
		p_task_system_dta->event = get_event_task_system();
	}

	temp = task_txpresion_get_latest_scaled(ID_TXPRESION_0, &valido);
	if (valido) {
		if (temp != sala_pasillo_PV) {
			sala_pasillo_PV = temp;
			print = true;
		}
	}

	temp = task_txpresion_get_latest_scaled(ID_TXPRESION_1, &valido);
	if (valido) {
		if (temp != sala_habitacion_PV) {
			sala_habitacion_PV = temp;
			print = true;
		}
	}

	switch (p_task_system_dta->state) {
	case ST_SYS_STABILIZING:
		if (print) {
			snprintf(linea1, sizeof(linea1), "  INMUNOSUPRIMIDO   ");
			snprintf(linea2, sizeof(linea2), "   Estabilizando    ");
			snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
			snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
					sala_pasillo_PV, sala_habitacion_PV);
			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			print = false;
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		estadoLeds(EV_LED_BLINK, EV_LED_OFF, EV_LED_BLINK, EV_LED_OFF);
		put_event_task_buzzer(EV_BUZZER_BLINK, ID_BUZZER_1);

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else {
			if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
					&& estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
				print = true;
				p_task_system_dta->state = ST_SYS_NORMAL;
				estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
				put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);

			} else {
				print = true;
				p_task_system_dta->state = ST_SYS_ALARM;
			}
		}
		break;

	case ST_SYS_NORMAL:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			if (print) {
				snprintf(linea1, sizeof(linea1), "  INMUNOSUPRIMIDO   ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Normal   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				print = false;
			}
		} else {
			print = true;
			p_task_system_dta->state = ST_SYS_ALERT;
			p_task_system_dta->tick = DEL_SYS_ALERT;
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_ALERT:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			// Si se normalizaron las presiones
			print = true;
			p_task_system_dta->tick = DEL_SYS_MIN;
			p_task_system_dta->state = ST_SYS_NORMAL;
			estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
			put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);
		} else {
			if (print) {
				snprintf(linea1, sizeof(linea1), "  INMUNOSUPRIMIDO   ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Alerta   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				if (!estable(sala_pasillo_PV, sala_pasillo_SP,
						sala_pasillo_desvio)) {
					if (!estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
						estadoLeds(EV_LED_OFF, EV_LED_BLINK, EV_LED_OFF,
								EV_LED_BLINK);
					} else {
						estadoLeds(EV_LED_OFF, EV_LED_BLINK, EV_LED_ON,
								EV_LED_OFF);
					}
				} else {
					estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_OFF, EV_LED_BLINK);
				}
				put_event_task_buzzer(EV_BUZZER_BLINK, ID_BUZZER_1);
				print = false;
			}
			// Si siguen anormales
			if (p_task_system_dta->tick > DEL_SYS_MIN) {
				p_task_system_dta->tick--;
			} else {
				print = true;
				p_task_system_dta->tick = DEL_SYS_MIN;
				p_task_system_dta->state = ST_SYS_ALARM;
			}
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_ALARM:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			// Si se normalizaron las presiones
			print = true;
			p_task_system_dta->tick = DEL_SYS_MIN;
			p_task_system_dta->state = ST_SYS_NORMAL;
			estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
			put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);
		} else {
			if (print) {
				snprintf(linea1, sizeof(linea1), "  INMUNOSUPRIMIDO   ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Alarma   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				if (!estable(sala_pasillo_PV, sala_pasillo_SP,
						sala_pasillo_desvio)) {
					if (!estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
						estadoLeds(EV_LED_OFF, EV_LED_ON, EV_LED_OFF,
								EV_LED_ON);
					} else {
						estadoLeds(EV_LED_OFF, EV_LED_ON, EV_LED_ON,
								EV_LED_OFF);
					}
				} else {
					estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_OFF, EV_LED_ON);
				}
				put_event_task_buzzer(EV_BUZZER_ON, ID_BUZZER_1);
				print = false;
			}
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	default:

		p_task_system_dta->tick = DEL_SYS_STABILIZING;
		p_task_system_dta->state = ST_SYS_STABILIZING;
		p_task_system_dta->event = EV_SYS_IDLE;
		p_task_system_dta->flag = false;

		break;
	}
}

void task_system_statechart_INFECTO(void) {
	task_system_dta_t *p_task_system_dta;
	bool valido = false;
	int16_t temp;

	/* Update Task System Data Pointer */
	p_task_system_dta = &task_system_dta_list[INFECTO];

	if (true == any_event_task_system()) {
		p_task_system_dta->flag = true;
		p_task_system_dta->event = get_event_task_system();
	}

	temp = task_txpresion_get_latest_scaled(ID_TXPRESION_0, &valido);
	if (valido) {
		if (temp != sala_pasillo_PV) {
			sala_pasillo_PV = temp;
			print = true;
		}
	}

	temp = task_txpresion_get_latest_scaled(ID_TXPRESION_1, &valido);
	if (valido) {
		if (temp != sala_habitacion_PV) {
			sala_habitacion_PV = temp;
			print = true;
		}
	}

	switch (p_task_system_dta->state) {
	case ST_SYS_STABILIZING:
		if (print) {
			snprintf(linea1, sizeof(linea1), " INFECTOCONTAGIOSO  ");
			snprintf(linea2, sizeof(linea2), "   Estabilizando    ");
			snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
			snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
					sala_pasillo_PV, sala_habitacion_PV);
			put_string_task_display(0, 0, linea1, MAX_COLUMNS);
			put_string_task_display(1, 0, linea2, MAX_COLUMNS);
			put_string_task_display(2, 0, linea3, MAX_COLUMNS);
			put_string_task_display(3, 0, linea4, MAX_COLUMNS);

			put_event_task_display(EV_DIS_WRITE);

			print = false;
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		estadoLeds(EV_LED_BLINK, EV_LED_OFF, EV_LED_BLINK, EV_LED_OFF);
		put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);

		if (p_task_system_dta->tick > DEL_SYS_MIN) {
			p_task_system_dta->tick--;
		} else {
			if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
					&& estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
				print = true;
				p_task_system_dta->state = ST_SYS_NORMAL;
				estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
				put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);

			} else {
				print = true;
				p_task_system_dta->state = ST_SYS_ALARM;
			}
		}
		break;

	case ST_SYS_NORMAL:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			if (print) {
				snprintf(linea1, sizeof(linea1), " INFECTOCONTAGIOSO  ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Normal   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				print = false;
			}
		} else {
			print = true;
			p_task_system_dta->state = ST_SYS_ALERT;
			p_task_system_dta->tick = DEL_SYS_ALERT;
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_ALERT:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			// Si se normalizaron las presiones
			print = true;
			p_task_system_dta->tick = DEL_SYS_MIN;
			p_task_system_dta->state = ST_SYS_NORMAL;
			estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
			put_event_task_buzzer(EV_BUZZER_OFF, ID_BUZZER_1);
		} else {
			if (print) {
				snprintf(linea1, sizeof(linea1), " INFECTOCONTAGIOSO  ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Alerta   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				if (!estable(sala_pasillo_PV, sala_pasillo_SP,
						sala_pasillo_desvio)) {
					if (!estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
						estadoLeds(EV_LED_OFF, EV_LED_BLINK, EV_LED_OFF,
								EV_LED_BLINK);
					} else {
						estadoLeds(EV_LED_OFF, EV_LED_BLINK, EV_LED_ON,
								EV_LED_OFF);
					}
				} else {
					estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_OFF, EV_LED_BLINK);
				}
				put_event_task_buzzer(EV_BUZZER_BLINK, ID_BUZZER_1);
				print = false;
			}
			// Si siguen anormales
			if (p_task_system_dta->tick > DEL_SYS_MIN) {
				p_task_system_dta->tick--;
			} else {
				print = true;
				p_task_system_dta->tick = DEL_SYS_MIN;
				p_task_system_dta->state = ST_SYS_ALARM;
			}
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	case ST_SYS_ALARM:
		if (estable(sala_pasillo_PV, sala_pasillo_SP, sala_pasillo_desvio)
				&& estable(sala_habitacion_PV, sala_habitacion_SP,
						sala_habitacion_desvio)) {
			// Si se normalizaron las presiones
			print = true;
			p_task_system_dta->tick = DEL_SYS_MIN;
			p_task_system_dta->state = ST_SYS_NORMAL;
			estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_ON, EV_LED_OFF);
		} else {
			if (print) {
				snprintf(linea1, sizeof(linea1), " INFECTOCONTAGIOSO  ");
				snprintf(linea2, sizeof(linea2), "  Estado:  Alarma   ");
				snprintf(linea3, sizeof(linea3), " Sala-Pas  Sala-Hab ");
				snprintf(linea4, sizeof(linea4), "  %4d Pa   %4d Pa ",
						sala_pasillo_PV, sala_habitacion_PV);
				put_string_task_display(0, 0, linea1, MAX_COLUMNS);
				put_string_task_display(1, 0, linea2, MAX_COLUMNS);
				put_string_task_display(2, 0, linea3, MAX_COLUMNS);
				put_string_task_display(3, 0, linea4, MAX_COLUMNS);

				put_event_task_display(EV_DIS_WRITE);

				if (!estable(sala_pasillo_PV, sala_pasillo_SP,
						sala_pasillo_desvio)) {
					if (!estable(sala_habitacion_PV, sala_habitacion_SP,
							sala_habitacion_desvio)) {
						estadoLeds(EV_LED_OFF, EV_LED_ON, EV_LED_OFF,
								EV_LED_ON);
					} else {
						estadoLeds(EV_LED_OFF, EV_LED_ON, EV_LED_ON,
								EV_LED_OFF);
					}
				} else {
					estadoLeds(EV_LED_ON, EV_LED_OFF, EV_LED_OFF, EV_LED_ON);
				}
				put_event_task_buzzer(EV_BUZZER_ON, ID_BUZZER_1);
				print = false;
			}
		}

		actuador_angulo = modulacion(sala_habitacion_PV, sala_habitacion_SP,
				sala_habitacion_desvio) * 1.8;
		put_event_task_servo_set_angle(ID_SERVO_1, actuador_angulo);
		put_event_task_servo(EV_SERVO_SET_ANGLE, ID_SERVO_1);

		if (p_task_system_dta->flag == true) {
			switch (p_task_system_dta->event) {
			case EV_SYS_BTN_ENTER_PRESSED:
				change = true;
				p_task_system_dta->flag = false;
				task_system_mode = SET_UP;
				break;
			default:
				break;
			}
		}
		break;

	default:

		p_task_system_dta->tick = DEL_SYS_STABILIZING;
		p_task_system_dta->state = ST_SYS_STABILIZING;
		p_task_system_dta->event = EV_SYS_IDLE;
		p_task_system_dta->flag = false;

		break;
	}
}

int16_t modulacion(int16_t medido, int16_t seteo, int16_t desvio) {
	int16_t minimo;
	int16_t maximo;
	int16_t temporal;

	if (desvio == 0)
		return 50;
	minimo = seteo - desvio;
	maximo = seteo + desvio;
	temporal = (medido - minimo) * (100) / (maximo - minimo);

	if (temporal < 0)
		return 0;
	else if (temporal > 100)
		return 100;
	else
		return temporal;
}

bool estable(int16_t medido, int16_t seteo, int16_t desvio) {
	int16_t minimo = seteo - desvio;
	int16_t maximo = seteo + desvio;

	if (medido >= minimo && medido <= maximo)
		return true;
	else
		return false;
}

void estadoLeds(task_led_ev_t l1, task_led_ev_t l2, task_led_ev_t l3,
		task_led_ev_t l4) {
	put_event_task_led(l1, ID_LED_1);
	put_event_task_led(l2, ID_LED_2);
	put_event_task_led(l3, ID_LED_3);
	put_event_task_led(l4, ID_LED_4);
}

/********************** end of file ******************************************/

/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_servo.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes. */
#include <stdlib.h>
#include "main.h"

/* Demo includes. */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes. */
#include "board.h"
#include "app.h"
#include "task_servo_attribute.h"
#include "task_servo_interface.h"

/********************** macros and definitions *******************************/
#define G_TASK_ACT_CNT_INIT				0ul
#define G_TASK_ACT_TICK_CNT_INI			0ul

#define SERVO_TICK_MIN					0ul
#define SERVO_TIME_ANGLE_MIN		  500ul
#define SERVO_TIME_ANGLE_MAX		 2500ul
#define SERVO_ANGLE_MIN					0ul
#define SERVO_ANGLE_MAX				  180ul
#define SERVO_PERIOD_US_DEFAULT		20000ul
#define SERVO_TIME_PER_ANGLE		   25ul

extern TIM_HandleTypeDef htim2;
/********************** internal data declaration ****************************/
static const task_servo_cfg_t task_servo_cfg_list[] = { { ID_SERVO_1, &htim2,
TIM_CHANNEL_3, SERVO_TIME_ANGLE_MIN, SERVO_TIME_ANGLE_MAX, SERVO_ANGLE_MIN, SERVO_ANGLE_MAX, SERVO_PERIOD_US_DEFAULT, SERVO_TIME_PER_ANGLE } };

#define SERVO_CFG_QTY	(sizeof(task_button_cfg_list)/sizeof(task_servo_cfg_t))

task_servo_dta_t task_servo_dta_list[] = { { SERVO_TICK_MIN, ST_SERVO_DISABLED,
		EV_SERVO_DISABLE, false, 90, 90 } };

#define SERVO_DTA_QTY	(sizeof(task_servo_dta_list)/sizeof(task_servo_dta_t))

/********************** internal functions declaration ***********************/
static void task_servo_statechart(void);

static int16_t clamp_i16(int16_t x, int16_t lo, int16_t hi);
static uint16_t angle_to_pulse_us(const task_servo_cfg_t *cfg,
		int16_t angle_deg);
static void servo_apply_pulse_us(const task_servo_cfg_t *cfg, uint16_t pulse_us);
static void servo_pwm_start(const task_servo_cfg_t *cfg);
static void servo_pwm_stop(const task_servo_cfg_t *cfg);
/********************** internal data definition *****************************/
const char *p_task_servo = "Task Servo (Servo Statechart)";
const char *p_task_servo_ = "Non-Blocking & Update By Time Code";

/********************** external data declaration *****************************/
uint32_t g_task_servo_cnt;
volatile uint32_t g_task_servo_tick_cnt;
/********************** external functions definition ************************/
void task_servo_init(void *parameters) {
	uint32_t index;

	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - %s", GET_NAME(task_servo_init), p_task_servo);
	LOGGER_INFO("  %s is a %s", GET_NAME(task_servo), p_task_servo_);

	g_task_servo_cnt = G_TASK_ACT_CNT_INIT;
	LOGGER_INFO("   %s = %lu", GET_NAME(g_task_servo_cnt), g_task_servo_cnt);

	for (index = 0; index < SERVO_DTA_QTY; index++) {
		const task_servo_cfg_t *p_task_servo_cfg = &task_servo_cfg_list[index];
		task_servo_dta_t *p_task_servo_dta = &task_servo_dta_list[index];

		p_task_servo_dta->state = ST_SERVO_DISABLED;
		p_task_servo_dta->event = EV_SERVO_DISABLE;
		p_task_servo_dta->flag = false;
		p_task_servo_dta->tick = SERVO_TICK_MIN;

		/* set CCR defensivo */
		uint16_t pulse = angle_to_pulse_us(p_task_servo_cfg,
				p_task_servo_dta->angle_current_deg);
		servo_apply_pulse_us(p_task_servo_cfg, pulse);

		/* PWM apagado al inicio */
		servo_pwm_stop(p_task_servo_cfg);

		LOGGER_INFO(" ");
		LOGGER_INFO("   servo[%lu] state=%lu angle_cur=%ld angle_tgt=%ld",
				(uint32_t )index, (uint32_t )p_task_servo_dta->state,
				(int32_t )p_task_servo_dta->angle_current_deg,
				(int32_t )p_task_servo_dta->angle_target_deg);
	}
}

void task_servo_update(void *parameters) {
	bool b_time_update_required = false;

	/* Protect shared resource */
	__asm("CPSID i");
	/* disable interrupts*/
	if (G_TASK_ACT_TICK_CNT_INI < g_task_servo_tick_cnt) {
		/* Update Tick Counter */
		g_task_servo_tick_cnt--;
		b_time_update_required = true;
	}
	__asm("CPSIE i");
	/* enable interrupts */

	while (b_time_update_required) {
		/* Update Task Counter */
		g_task_servo_cnt++;

		/* Run Task Statechart */
		task_servo_statechart();

		/* Protect shared resource */
		__asm("CPSID i");
		/* disable interrupts */
		if (G_TASK_ACT_TICK_CNT_INI < g_task_servo_tick_cnt) {
			/* Update Tick Counter */
			g_task_servo_tick_cnt--;
			b_time_update_required = true;
		} else {
			b_time_update_required = false;
		}
		__asm("CPSIE i");
		/* enable interrupts */
	}
}

void task_servo_statechart(void) {
	uint32_t index;
	const task_servo_cfg_t *p_task_servo_cfg;
	task_servo_dta_t *p_task_servo_dta;

	for (index = 0; index < SERVO_DTA_QTY; index++) {

		p_task_servo_cfg = &task_servo_cfg_list[index];
		p_task_servo_dta = &task_servo_dta_list[index];

		switch (p_task_servo_dta->state) {

		case ST_SERVO_DISABLED:

			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_ENABLE) {
				p_task_servo_dta->flag = false;

				/* aplicar ángulo actual y arrancar PWM */
				servo_apply_pulse_us(p_task_servo_cfg,
						angle_to_pulse_us(p_task_servo_cfg,
								p_task_servo_dta->angle_current_deg));
				servo_pwm_start(p_task_servo_cfg);

				p_task_servo_dta->state = ST_SERVO_IDLE;
			}

			/* si set_angle estando disabled, guardo (no genero PWM) */
			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_SET_ANGLE) {
				p_task_servo_dta->flag = false;
				p_task_servo_dta->angle_target_deg = clamp_i16(
						p_task_servo_dta->angle_target_deg,
						p_task_servo_cfg->angle_min_deg,
						p_task_servo_cfg->angle_max_deg);
				p_task_servo_dta->angle_current_deg =
						p_task_servo_dta->angle_target_deg;
			}

			break;

		case ST_SERVO_IDLE:

			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_DISABLE) {
				p_task_servo_dta->flag = false;
				servo_pwm_stop(p_task_servo_cfg);
				p_task_servo_dta->state = ST_SERVO_DISABLED;
				break;
			}

			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_SET_ANGLE) {
				p_task_servo_dta->flag = false;

				p_task_servo_dta->angle_target_deg = clamp_i16(
						p_task_servo_dta->angle_target_deg,
						p_task_servo_cfg->angle_min_deg,
						p_task_servo_cfg->angle_max_deg);

				/* movimiento suave */
				p_task_servo_dta->tick = p_task_servo_cfg->step_delay_ms;
				p_task_servo_dta->state = ST_SERVO_MOVING;
			}

			break;

		case ST_SERVO_MOVING:
			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_DISABLE) {
				p_task_servo_dta->flag = false;
				servo_pwm_stop(p_task_servo_cfg);
				p_task_servo_dta->state = ST_SERVO_DISABLED;
				break;
			}

			/* retarget “en caliente” */
			if (p_task_servo_dta->flag
					&& p_task_servo_dta->event == EV_SERVO_SET_ANGLE) {
				p_task_servo_dta->flag = false;
				p_task_servo_dta->angle_target_deg = clamp_i16(
						p_task_servo_dta->angle_target_deg,
						p_task_servo_cfg->angle_min_deg,
						p_task_servo_cfg->angle_max_deg);
			}

			if (p_task_servo_dta->tick == 0ul) {

				if (p_task_servo_dta->angle_current_deg
						< p_task_servo_dta->angle_target_deg) {
					p_task_servo_dta->angle_current_deg++;
				} else if (p_task_servo_dta->angle_current_deg
						> p_task_servo_dta->angle_target_deg) {
					p_task_servo_dta->angle_current_deg--;
				}

				servo_apply_pulse_us(p_task_servo_cfg,
						angle_to_pulse_us(p_task_servo_cfg,
								p_task_servo_dta->angle_current_deg));

				if (p_task_servo_dta->angle_current_deg
						== p_task_servo_dta->angle_target_deg) {
					p_task_servo_dta->state = ST_SERVO_IDLE;
				} else {
					p_task_servo_dta->tick = p_task_servo_cfg->step_delay_ms;
				}

			} else {
				p_task_servo_dta->tick--;
			}

			break;

		default:
			servo_pwm_stop(p_task_servo_cfg);
			p_task_servo_dta->tick = SERVO_TICK_MIN;
			p_task_servo_dta->state = ST_SERVO_DISABLED;
			p_task_servo_dta->event = EV_SERVO_DISABLE;
			p_task_servo_dta->flag = false;
			break;
		}
	}
}

/********************** helpers *****************************/
static int16_t clamp_i16(int16_t x, int16_t lo, int16_t hi) {
	if (x < lo)
		return lo;
	if (x > hi)
		return hi;
	return x;
}

static uint16_t angle_to_pulse_us(const task_servo_cfg_t *cfg,
		int16_t angle_deg) {
	int16_t a = clamp_i16(angle_deg, cfg->angle_min_deg, cfg->angle_max_deg);

	int32_t num = (int32_t) (a - cfg->angle_min_deg)
			* (int32_t) (cfg->pulse_max_us - cfg->pulse_min_us);
	int32_t den = (int32_t) (cfg->angle_max_deg - cfg->angle_min_deg);

	if (den == 0)
		return cfg->pulse_min_us;

	return (uint16_t) (cfg->pulse_min_us + (num / den));
}

static void servo_apply_pulse_us(const task_servo_cfg_t *cfg, uint16_t pulse_us) {
	__HAL_TIM_SET_COMPARE(cfg->htim, cfg->channel, pulse_us);
}

static void servo_pwm_start(const task_servo_cfg_t *cfg) {
	HAL_TIM_PWM_Start(cfg->htim, cfg->channel);
}

static void servo_pwm_stop(const task_servo_cfg_t *cfg) {
	HAL_TIM_PWM_Stop(cfg->htim, cfg->channel);
}

/********************** end of file ******************************************/

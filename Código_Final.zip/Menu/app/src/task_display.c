/*
 * Copyright (c) 2025 Nicolás Alejandro Potenza <npotenza@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_display.c
 * @date   : Nov 25, 2025
 * @author : Nicolás Alejandro Potenza <npotenza@fi.uba.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_display_attribute.h"
#include "task_display_interface.h"

/********************** macros and definitions *******************************/
#define G_TASK_SYS_CNT_INI			(0ul)
#define G_TASK_SYS_TICK_CNT_INI		(0ul)

#define DEL_DIS_MIN					(0ul)
#define DEL_DIS_MED					(5ul)
#define DEL_DIS_MAX					(5ul)

#define MASK_UPPER_DATA				(0xF0)
#define MASK_LOWER_DATA				(0x0F)

/********************** internal data declaration ****************************/
task_display_dta_t task_display_dta_list[] = { { DEL_DIS_MIN, ST_DIS_IDLE,
		EV_DIS_IDLE, false } };

#define DISPLAY_DTA_QTY	(sizeof(task_display_dta_list)/sizeof(task_display_dta_t))

static const uint8_t row_offsets[4] = { 0x00, 0x40, 0x14, 0x54 };

/********************** internal functions declaration ***********************/
void task_display_statechart(void);

void LCD_CleanRAM(void);
void LCD_init(void);

void LCD_SetBacklight(void);
void LCD_SetCursor(uint8_t row, uint8_t col);

static void LCD_Send_Cmd(uint8_t data);
static void LCD_Send_Data(uint8_t data);

static void I2C_Write(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data,
		uint16_t size);
static HAL_I2C_StateTypeDef I2C_isReady();
/********************** internal data definition *****************************/
const char *p_task_display = "Task Display (Display Statechart)";
const char *p_task_display_ = "Non-Blocking & Update By Time Code";

/********************** external data declaration ****************************/
uint32_t g_task_display_cnt;
volatile uint32_t g_task_display_tick_cnt;

/********************** external functions definition ************************/
void task_display_init(void *parameters) {
	uint16_t index;
	task_display_dta_t *p_task_display_dta;
	task_display_st_t state;
	task_display_ev_t event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - %s", GET_NAME(task_display_init),
			p_task_display);
	LOGGER_INFO("  %s is a %s", GET_NAME(task_display), p_task_display_);

	/* Init & Print out: Task execution counter */
	g_task_display_cnt = G_TASK_SYS_CNT_INI;
	LOGGER_INFO("   %s = %lu", GET_NAME(g_task_display_cnt), g_task_display_cnt);

	for (index = 0; DISPLAY_DTA_QTY > index; index++) {
		/* Update Task display Configuration & Data Pointer */
		p_task_display_dta = &task_display_dta_list[index];

		/* Init & Print out: Task execution FSM */
		state = ST_DIS_IDLE;
		p_task_display_dta->state = state;

		event = EV_DIS_IDLE;
		p_task_display_dta->event = event;

		b_event = false;
		p_task_display_dta->flag = b_event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu", GET_NAME(index),
				(uint32_t )index, GET_NAME(state), (uint32_t )state,
				GET_NAME(event), (uint32_t )event);
	}

	init_queue_event_task_display();
	LCD_init();
}

void task_display_update(void *parameters) {
	bool b_time_update_required = false;

	/* Protect shared resource */
	__asm("CPSID i");
	/* disable interrupts */
	if (G_TASK_SYS_TICK_CNT_INI < g_task_display_tick_cnt) {
		/* Update Tick Counter */
		g_task_display_tick_cnt--;
		b_time_update_required = true;
	}
	__asm("CPSIE i");
	/* enable interrupts */

	while (b_time_update_required) {
		/* Update Task Counter */
		g_task_display_cnt++;

		/* Run Task Statechart */
		task_display_statechart();

		/* Protect shared resource */
		__asm("CPSID i");
		/* disable interrupts */
		if (G_TASK_SYS_TICK_CNT_INI < g_task_display_tick_cnt) {
			/* Update Tick Counter */
			g_task_display_tick_cnt--;
			b_time_update_required = true;
		} else {
			b_time_update_required = false;
		}
		__asm("CPSIE i");
		/* enable interrupts */
	}
}

void task_display_statechart(void) {
	task_display_dta_t *p_task_display_dta;
	static uint8_t row;
	static uint8_t col;
	static bool backlight_write;

	/* Update Task Display Data Pointer */
	p_task_display_dta = &task_display_dta_list[0];

	if (true == any_event_task_display()) {
		p_task_display_dta->flag = true;
		p_task_display_dta->event = get_event_task_display();
	}

	switch (p_task_display_dta->state) {

	case ST_DIS_IDLE:

		if (true == p_task_display_dta->flag) {
			if (EV_DIS_WRITE == p_task_display_dta->event) {
				p_task_display_dta->flag = false;
				p_task_display_dta->state = ST_DIS_ACTIVE_01;
				row = 0;
			} else if (EV_DIS_BACKLIGHT == p_task_display_dta->event) {
				p_task_display_dta->flag = false;
				p_task_display_dta->state = ST_DIS_BACKLIGHT;
				backlight_write = false;
			}
		}
		break;

	case ST_DIS_ACTIVE_01:

		if (row >= MAX_ROWS) {
			p_task_display_dta->state = ST_DIS_IDLE;
		} else {
			col = 0;
			LCD_SetCursor(row, col);
			p_task_display_dta->tick = DEL_DIS_MAX;
			p_task_display_dta->state = ST_DIS_ACTIVE_02;
		}

		break;

	case ST_DIS_ACTIVE_02:

		if (p_task_display_dta->tick > DEL_DIS_MIN) {
			p_task_display_dta->tick--;
		} else {
			LCD_Send_Data(display_memory_ram[row][col]);
			p_task_display_dta->tick = DEL_DIS_MAX;

			col++;

			if (col >= MAX_COLUMNS) {
				row++;
				p_task_display_dta->tick = DEL_DIS_MIN;
				p_task_display_dta->state = ST_DIS_ACTIVE_01;
			}
		}

		break;

	case ST_DIS_BACKLIGHT:

		if (false == backlight_write) {
			LCD_SetBacklight();
			p_task_display_dta->tick = DEL_DIS_MAX;
			backlight_write = true;
		} else {
			if (p_task_display_dta->tick > DEL_DIS_MIN) {
				p_task_display_dta->tick--;
			} else {
				p_task_display_dta->state = ST_DIS_IDLE;
			}
		}

		break;

	default:

		p_task_display_dta->tick = DEL_DIS_MIN;
		p_task_display_dta->state = ST_DIS_IDLE;
		p_task_display_dta->event = EV_DIS_IDLE;
		p_task_display_dta->flag = false;

		break;
	}
}

void LCD_init(void) {
	HAL_Delay(50); // recomendado por el fabricante

	LCD_Send_Cmd(0x33);
	HAL_Delay(2);

	LCD_Send_Cmd(0x32);
	HAL_Delay(2);

	LCD_Send_Cmd(0x28);  // 4 bits, 2 líneas, 5x8 dots
	HAL_Delay(1);

	LCD_Send_Cmd(0x0C);  // display ON, cursor OFF, blink OFF
	HAL_Delay(1);

	LCD_Send_Cmd(0x06);  // entry mode: incrementa, sin shift
	HAL_Delay(1);

	LCD_Send_Cmd(0x01);  // clear display
	HAL_Delay(2);

	LCD_CleanRAM();
}

void LCD_CleanRAM(void) {
	for (uint8_t r = 0; r < MAX_ROWS; r++)
		for (uint8_t c = 0; c < MAX_COLUMNS; c++)
			display_memory_ram[r][c] = ' '; // comando normal ~37 µs → 1 ms holgado
}

static void LCD_Send_Cmd(uint8_t cmd) {
	static uint8_t temp[4];
	uint8_t upper = (cmd & MASK_UPPER_DATA);
	uint8_t lower = (cmd & MASK_LOWER_DATA) << 4;

	temp[0] = (upper | LCD_EN | lcd_backlight);		// Enable = 1
	temp[1] = ((upper & ~LCD_EN) | lcd_backlight);	// Enable = 0
	temp[2] = (lower | LCD_EN | lcd_backlight);		// Enable = 1
	temp[3] = ((lower & ~LCD_EN) | lcd_backlight);	// Enable = 0
	I2C_Write(lcd_i2c, LCD_I2C_ADDR, temp, 4);
}

static void LCD_Send_Data(uint8_t data) {
	static uint8_t temp[4];
	uint8_t upper = (data & MASK_UPPER_DATA);
	uint8_t lower = (data & MASK_LOWER_DATA) << 4;

	temp[0] = (upper | LCD_EN | LCD_RS | lcd_backlight);	// Enable = 1
	temp[1] = ((upper & ~LCD_EN) | LCD_RS | lcd_backlight);	// Enable = 0
	temp[2] = (lower | LCD_EN | LCD_RS | lcd_backlight);	// Enable = 1
	temp[3] = ((lower & ~LCD_EN) | LCD_RS | lcd_backlight);	// Enable = 0
	I2C_Write(lcd_i2c, LCD_I2C_ADDR, temp, 4);
}

void LCD_SetBacklight(void) {
	I2C_Write(lcd_i2c, LCD_I2C_ADDR, &lcd_backlight, 1);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
	LCD_Send_Cmd(0x80 | (row_offsets[row] + col));
}

/******************************** driver i2c *********************************/

static void I2C_Write(I2C_HandleTypeDef *hi2c, uint16_t address, uint8_t *data,
		uint16_t size) {
	HAL_I2C_Master_Transmit_IT(hi2c, address, data, size);
}

static HAL_I2C_StateTypeDef I2C_isReady() {
	return (HAL_I2C_GetState(lcd_i2c) == HAL_I2C_STATE_READY);
}

/********************** end of file ******************************************/

/*
 * Copyright (c) 2025 Nicolás Alejandro Potenza <npotenza@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_memory.c
 * @date   : Dec 07, 2025
 * @author : Nicolás Alejandro Potenza <npotenza@fi.uba.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_memory_attribute.h"
#include "task_memory_interface.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"

/********************** macros and definitions *******************************/
#define G_TASK_SYS_CNT_INI			(0ul)
#define G_TASK_SYS_TICK_CNT_INI		(0ul)

#define DEL_MEM_MIN					(0ul)
#define DEL_MEM_MED					(5ul)
#define DEL_MEM_MAX					(5ul)

/********************** internal data declaration ****************************/
task_memory_dta_t task_memory_dta_list[] = { { DEL_MEM_MIN, ST_MEM_IDLE,
		EV_MEM_IDLE, false } };

#define MEMORY_DTA_QTY	(sizeof(task_memory_dta_list)/sizeof(task_memory_dta_t))

static task_memory_req_t s_req;
static bool s_req_valid = false;

static uint16_t s_curr_addr;
static uint16_t s_remaining;
static uint16_t s_offset;     // bytes ya procesados dentro del request
static uint16_t s_chunk;      // bytes del chunk actual

static uint8_t s_txbuf[2 + EEPROM_PAGE_SIZE];

/********************** internal functions declaration ***********************/
void task_memory_statechart(void);

static uint16_t calc_chunk(uint16_t addr, uint16_t remaining);
static bool eeprom_start_write_chunk(uint16_t addr, const uint8_t *data,
		uint16_t chunk);
static bool eeprom_start_set_addr(uint16_t addr);
static bool eeprom_start_read(uint8_t *dst, uint16_t len);

static bool I2C_isReady(void);
/********************** internal data definition *****************************/
const char *p_task_memory = "Task Memory (Memory Statechart)";
const char *p_task_memory_ = "Non-Blocking & Update By Time Code";

/********************** external data declaration ****************************/
uint32_t g_task_memory_cnt;
volatile uint32_t g_task_memory_tick_cnt;

/********************** external functions definition ************************/
void task_memory_init(void *parameters) {
	uint16_t index;
	task_memory_dta_t *p_task_memory_dta;
	task_memory_st_t state;
	task_memory_ev_t event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - %s", GET_NAME(task_memory_init),
			p_task_memory);
	LOGGER_INFO("  %s is a %s", GET_NAME(task_memory), p_task_memory_);

	/* Init & Print out: Task execution counter */
	g_task_memory_cnt = G_TASK_SYS_CNT_INI;
	LOGGER_INFO("   %s = %lu", GET_NAME(g_task_memory_cnt), g_task_memory_cnt);

	for (index = 0; MEMORY_DTA_QTY > index; index++) {
		/* Update Task memory Configuration & Data Pointer */
		p_task_memory_dta = &task_memory_dta_list[index];

		/* Init & Print out: Task execution FSM */
		state = ST_MEM_IDLE;
		p_task_memory_dta->state = state;

		event = EV_MEM_IDLE;
		p_task_memory_dta->event = event;

		b_event = false;
		p_task_memory_dta->flag = b_event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu", GET_NAME(index),
				(uint32_t )index, GET_NAME(state), (uint32_t )state,
				GET_NAME(event), (uint32_t )event);
	}

	init_queue_event_task_memory();
}

void task_memory_update(void *parameters) {
	bool b_time_update_required = false;

	/* Protect shared resource */
	__asm("CPSID i");
	/* disable interrupts */
	if (G_TASK_SYS_TICK_CNT_INI < g_task_memory_tick_cnt) {
		/* Update Tick Counter */
		g_task_memory_tick_cnt--;
		b_time_update_required = true;
	}
	__asm("CPSIE i");
	/* enable interrupts */

	while (b_time_update_required) {
		/* Update Task Counter */
		g_task_memory_cnt++;

		/* Run Task Statechart */
		task_memory_statechart();

		/* Protect shared resource */
		__asm("CPSID i");
		/* disable interrupts */
		if (G_TASK_SYS_TICK_CNT_INI < g_task_memory_tick_cnt) {
			/* Update Tick Counter */
			g_task_memory_tick_cnt--;
			b_time_update_required = true;
		} else {
			b_time_update_required = false;
		}
		__asm("CPSIE i");
		/* enable interrupts */
	}
}

void task_memory_statechart(void) {
	task_memory_dta_t *p_task_memory_dta;

	/* Update Task Memory Data Pointer */
	p_task_memory_dta = &task_memory_dta_list[0];

	if (!s_req_valid && true == any_event_task_memory()) {
		p_task_memory_dta->flag = true;
		s_req = get_event_task_memory();
		p_task_memory_dta->event = s_req.event;
		s_req_valid = true;

		s_curr_addr = s_req.address;
		s_remaining = s_req.length;
		s_offset = 0;
	}

	switch (p_task_memory_dta->state) {

	case ST_MEM_IDLE:

		if (s_req_valid && p_task_memory_dta->flag) {
			p_task_memory_dta->flag = false;
			if (s_req.event == EV_MEM_WRITE)
				p_task_memory_dta->state = ST_MEM_WRITE;
			else if (s_req.event == EV_MEM_READ)
				p_task_memory_dta->state = ST_MEM_SET_ADDRESS;
		}

		break;

		// -------- WRITE --------
	case ST_MEM_WRITE:
		if (!I2C_isReady())
			break;

		if (s_remaining == 0) {
			s_req_valid = false;
			p_task_memory_dta->state = ST_MEM_IDLE;
			break;
		}

		s_chunk = calc_chunk(s_curr_addr, s_remaining);

		if (eeprom_start_write_chunk(s_curr_addr, &memory_ram[s_curr_addr],
				s_chunk)) {
			p_task_memory_dta->state = ST_MEM_WRITING;
		}
		// si no pudo arrancar, se reintenta en próxima vuelta
		break;

	case ST_MEM_WRITING:
		// esperar a que termine la TX IT
		if (!I2C_isReady())
			break;

		// TX finalizada: avanzar contadores
		s_curr_addr += s_chunk;
		s_remaining -= s_chunk;
		s_offset += s_chunk;

		// ahora ACK polling (EEPROM puede NACKear mientras escribe internamente)
		p_task_memory_dta->state = ST_MEM_WRITE_POLL;
		break;

	case ST_MEM_WRITE_POLL: {
		static bool poll_inflight = false;

		if (!poll_inflight) {
			if (!I2C_isReady())
				break;

			/* Limpiar error previo ANTES de arrancar un nuevo poll */
			__HAL_I2C_CLEAR_FLAG(eeprom_i2c, I2C_FLAG_AF);
			eeprom_i2c->ErrorCode = HAL_I2C_ERROR_NONE;

			(void) eeprom_start_set_addr(0x0000);
			poll_inflight = true;
			break;
		}

		/* Esperar a que termine la TX */
		if (!I2C_isReady())
			break;

		poll_inflight = false;

		uint32_t err = HAL_I2C_GetError(eeprom_i2c);

		if (err == HAL_I2C_ERROR_NONE) {
			/* EEPROM respondió ACK → lista */
			if (s_remaining == 0) {
				s_req_valid = false;
				p_task_memory_dta->state = ST_MEM_IDLE;

				put_event_task_system(EV_SYS_MEM_WRITE_DONE);
			} else {
				p_task_memory_dta->state = ST_MEM_WRITE;
			}
		} else if (err & HAL_I2C_ERROR_AF) {
			/* NACK → EEPROM sigue ocupada */
			/* quedarse en ST_MEM_WRITE_POLL */
		} else {
			/* Error real */
			s_req_valid = false;
			p_task_memory_dta->state = ST_MEM_IDLE;
		}

		break;
	}
		// -------- READ --------
	case ST_MEM_SET_ADDRESS:
		if (!I2C_isReady())
			break;

		if (s_remaining == 0) {
			s_req_valid = false;
			p_task_memory_dta->state = ST_MEM_IDLE;
			break;
		}

		// set internal address para lectura (arranca TX IT de 2 bytes)
		if (eeprom_start_set_addr(s_curr_addr)) {
			p_task_memory_dta->state = ST_MEM_READ;
		}
		break;

	case ST_MEM_READ:
		if (!I2C_isReady())
			break;

		// Para leer, podés leer de a chunk también si querés.
		// Acá leo todo el tramo pedido en un único Receive_IT.
		if (eeprom_start_read(&memory_ram[s_curr_addr], s_remaining)) {
			p_task_memory_dta->state = ST_MEM_READING;
		}
		break;

	case ST_MEM_READING:
		if (!I2C_isReady())
			break;

		s_req_valid = false;
		p_task_memory_dta->state = ST_MEM_IDLE;

		put_event_task_system(EV_SYS_MEM_READ_DONE);    // NUEVO
		break;

	default:
		p_task_memory_dta->state = ST_MEM_IDLE;
		s_req_valid = false;
		break;
	}
}

/******************************** driver i2c *********************************/

static uint16_t calc_chunk(uint16_t addr, uint16_t remaining) {
	uint16_t page_space = EEPROM_PAGE_SIZE
			- (uint16_t) (addr % EEPROM_PAGE_SIZE);
	return (remaining < page_space) ? remaining : page_space;
}

static bool eeprom_start_write_chunk(uint16_t addr, const uint8_t *data,
		uint16_t chunk) {
	s_txbuf[0] = (uint8_t) (addr >> 8);
	s_txbuf[1] = (uint8_t) (addr & 0xFF);
	for (uint16_t i = 0; i < chunk; i++)
		s_txbuf[2 + i] = data[i];

	return (HAL_OK
			== HAL_I2C_Master_Transmit_IT(eeprom_i2c, EEPROM_I2C_ADDR, s_txbuf,
					2 + chunk));
}

static bool eeprom_start_set_addr(uint16_t addr) {
	static uint8_t a[2];
	a[0] = (uint8_t) (addr >> 8);
	a[1] = (uint8_t) (addr & 0xFF);
	return (HAL_OK
			== HAL_I2C_Master_Transmit_IT(eeprom_i2c, EEPROM_I2C_ADDR, a, 2));
}

static bool eeprom_start_read(uint8_t *dst, uint16_t len) {
	return (HAL_OK
			== HAL_I2C_Master_Receive_IT(eeprom_i2c, EEPROM_I2C_ADDR, dst, len));
}

static bool I2C_isReady(void) {
	return (HAL_I2C_GetState(eeprom_i2c) == HAL_I2C_STATE_READY);
}

/********************** end of file ******************************************/
